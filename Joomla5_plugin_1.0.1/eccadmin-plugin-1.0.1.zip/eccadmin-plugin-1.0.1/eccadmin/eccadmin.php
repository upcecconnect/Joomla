<?php
defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Plugin\CMSPlugin;
use Joomla\Database\DatabaseDriver;
use Joomla\Registry\Registry;

/**
 * System helper: enhances admin UI for the eCommerceConnect payment settings.
 * - Clears rendered textarea values for sensitive fields.
 * - Shows a green "[Saved]" badge when a value exists in DB.
 * - Ensures inline-help is visible.
 */
class PlgSystemEccadmin extends CMSPlugin
{
    private string $targetFolder  = 'j2store';
    private string $targetElement = 'payment_ecommerceconnect';
    private array $secretFields = ['private_key', 'private_key_test', 'work_crt', 'test_crt'];

    public function __construct(&$subject, $config)
    {
        parent::__construct($subject, $config);
        $this->loadLanguage();
    }

    public function onAfterRender()
    {
        $app = Factory::getApplication();
        if (!$app->isClient('administrator')) return;

        $in = $app->getInput();
        if ($in->getCmd('option') !== 'com_plugins' || $in->getCmd('view') !== 'plugin') return;

        $extId = (int) ($in->getInt('extension_id') ?: $in->getInt('id'));
        if ($extId < 1) return;

        /** @var DatabaseDriver $db */
        $db = Factory::getContainer()->get(DatabaseDriver::class);
        $q  = $db->getQuery(true)
            ->select([$db->qn('element'), $db->qn('folder'), $db->qn('params')])
            ->from($db->qn('#__extensions'))
            ->where($db->qn('extension_id') . ' = ' . $extId)
            ->setLimit(1);
        $db->setQuery($q);
        $row = $db->loadObject();

        if (!$row || $row->element !== $this->targetElement || $row->folder !== $this->targetFolder) return;

        $params = new Registry($row->params ?? '{}');
        $body   = $app->getBody();

        $savedLabel = Text::_('PLG_ECCADMIN_SAVED_BADGE');
        // Bootstrap 5 badge with green background
        $labelHtml  = ' <span class="badge bg-success align-middle ms-2">' . htmlspecialchars($savedLabel, ENT_QUOTES) . '</span>';

        foreach ($this->secretFields as $f) {
            $hasValue = trim((string) $params->get($f)) !== '';

            // Clear textarea contents for secret field; append green badge if value exists
            $pattern = '#(<textarea[^>]*name="jform\[params\]\[' . preg_quote($f, '#') . '\]"[^>]*>)(.*?)(</textarea>)#si';
            if ($hasValue) {
                $body = preg_replace_callback($pattern, function($m) use ($labelHtml) {
                    return $m[1] . $m[3] . $labelHtml;
                }, $body, 1);
            } else {
                $body = preg_replace($pattern, '$1$3', $body, 1);
            }

            // Unhide inline-help for this field (remove d-none)
            $body = preg_replace(
                '#(<div\s+id="jform_params_' . preg_quote($f, '#') . '-desc"[^>]*class="[^"]*)\bd-none\b#i',
                '$1',
                $body,
                1
            );
        }

        // Unhide any global inline-help blocks
        $body = preg_replace('#\bhide-aware-inline-help\s+d-none\b#i', 'hide-aware-inline-help', $body);

        $app->setBody($body);
    }
}
