<?php
defined('_JEXEC') or die;

use JetBrains\PhpStorm\NoReturn;
use Joomla\CMS\Factory;
use Joomla\CMS\Form\Form;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Uri\Uri;
use Joomla\CMS\Http\HttpFactory;
use Joomla\CMS\Session\Session;
use Joomla\Database\DatabaseDriver;
use Joomla\Registry\Registry;

require_once JPATH_ADMINISTRATOR . '/components/com_j2store/library/plugins/payment.php';

class plgJ2StorePayment_ecommerceconnect extends J2StorePaymentPlugin
{
    public $_element = 'payment_ecommerceconnect';
    private array $secretFields = ['private_key', 'private_key_test', 'work_crt', 'test_crt'];

    public function __construct($subject, $config = [])
    {
        parent::__construct($subject, $config);
        $this->loadLanguage();
    }

    public function _renderForm($data): string
    {
        $vars = (object)[
            'title' => $this->params->get('title', 'eCommerceConnect'),
            'description' => $this->params->get('description', 'Pay with eCommerceConnect (Debit/Credit Cards)'),
            'logo' => Uri::root() . 'plugins/j2store/payment_ecommerceconnect/payment_ecommerceconnect/media/logo.svg',
        ];

        return $this->_getLayout('form', $vars);
    }

    public function _prePayment($data): string
    {
        $order = $data['order'] ?? null;
        if (!$order) {
            return $this->_getLayout('message', (object)['message' => 'Order object is missing.']);
        }

        $gatewayUrl = rtrim((string)$this->params->get('url', ''), '/');
        if (empty($gatewayUrl)) {
            return $this->_getLayout('message', (object)['message' => Text::_('PLG_ECC_URL') . ' is not set in plugin settings.']);
        }

        $payload = $this->buildGatewayPayload($order);

        $payload['Signature'] = $this->signData($payload['_sign_string']);

        $vars = (object)[
            'action_url' => $gatewayUrl . '/go/pay',
            'fields' => $this->filterPostFields($payload),
            'skip_form' => (int)$this->params->get('skip_form', 0) === 1,

            'return_url' => Uri::root() . 'index.php?option=com_j2store&view=checkout&task=confirmPayment&orderpayment_type=' . $this->_element . '&paction=display',
            'cancel_url' => Uri::root() . 'index.php?option=com_j2store&view=checkout&task=confirmPayment&orderpayment_type=' . $this->_element . '&paction=cancel',
            'callback_url' => Uri::root() . 'index.php?option=com_j2store&view=checkout&task=confirmPayment&orderpayment_type=' . $this->_element . '&paction=callback',
        ];

        return $this->_getLayout('prepayment', $vars);
    }

    public function _postPayment($data): string
    {
        $app = Factory::getApplication();
        $paction = $app->input->getCmd('paction', 'display');

        if ($paction === 'cancel') {
            return $this->_getLayout('message', (object)['message' => Text::_('PLG_ECC_MSG_CANCEL')]);
        }
        if ($paction === 'callback') {
            $this->handleCallback();

            return '';
        }
        if ($paction === 'capture') {
            $this->handleCapture();

            return '';
        }

        return $this->_displayArticle();
    }

    protected function buildGatewayPayload($order): array
    {
        $orderId = $this->getOrderId($order);
        $orderTotal = $this->getOrderTotal($order);
        $orderCurrAlp = strtoupper($this->getOrderCurrencyAlpha($order)); // e.g. UAH

        $available = $this->availableCurrencies();
        $contractCurrency = (string)$this->params->get('currency', '980');
        $altCurrency = (int)$this->params->get('alt_currency', 840);
        $eurRate = (float)$this->params->get('eur_conversion', 1.0);
        $usdRate = (float)$this->params->get('usd_conversion', 1.0);

        $total_amount = (int)round($orderTotal * 100);
        $alt_total = $total_amount;

        $orderNumeric = $available[$orderCurrAlp] ?? null;

        if ($orderNumeric === $contractCurrency) {
            $altCurrency = (int)$contractCurrency;
        } else {
            if ($altCurrency === 978 && $eurRate > 0) {
                $alt_total = (int)round(($orderTotal / $eurRate) * 100);
            } else if ($altCurrency === 840 && $usdRate > 0) {
                $alt_total = (int)round(($orderTotal / $usdRate) * 100);
            }
        }

        $merchantID = trim((string)$this->params->get('merchant_id', ''));
        $terminalID = trim((string)$this->params->get('terminal_id', ''));
        $purchaseTime = date('ymdHis');
        $locale = (string)$this->params->get('lang', 'en');
        $delay = $this->params->get('txn_type', 'sale') === 'authorize' ? '1' : '0';
        $sd = $this->getSessionToken();
        $purchaseDesc = $this->getSiteName() . ' - ' . $orderId;

        // "$merchantID;$terminalID;$purchaseTime;$orderId,$delay;$contractCurrency,$altCurrency;$total_amount,$alt_total;$sd;"
        $signData = implode(';', [
                $merchantID,
                $terminalID,
                $purchaseTime,
                $orderId . ',' . $delay,
                $contractCurrency . ',' . $altCurrency,
                $total_amount . ',' . $alt_total,
                $sd,
            ]) . ';';

        $fields = [
            'Version' => '1',
            'MerchantID' => $merchantID,
            'TerminalID' => $terminalID,
            'OrderID' => $orderId,
            'Delay' => $delay,
            'TotalAmount' => $total_amount,
            'AltTotalAmount' => $alt_total,
            'Currency' => (int)$contractCurrency,
            'AltCurrency' => (int)$altCurrency,
            'PurchaseTime' => $purchaseTime,
            'PurchaseDesc' => $purchaseDesc,
            'SD' => $sd,
            'locale' => $locale,
        ];

        $storedToken = $this->getStoredUserTokenForOrder($order);
        if ($storedToken) {
            $fields['UPCToken'] = $storedToken;
        }

        $fields['_sign_string'] = $signData;

        return $fields;
    }

    /** Підпис SHA512 із PEM (prod/test) */
    protected function signData(string $data): string
    {
        $isTest = (int)$this->params->get('testmode', 1) === 1;
        $privRaw = $isTest
            ? (string)$this->params->get('private_key_test', '')
            : (string)$this->params->get('private_key', '');

        if (empty($privRaw)) {
            return '';
        }

        $pem = $privRaw;
        $pkey = openssl_pkey_get_private($pem);
        if (!$pkey) {
            return '';
        }

        $signature = '';
        $ok = openssl_sign($data, $signature, $pkey, OPENSSL_ALGO_SHA512);
        if (PHP_VERSION_ID < 80000) {
            openssl_free_key($pkey);
        }

        return $ok ? base64_encode($signature) : '';
    }

    /** Забираємо службове поле _sign_string із POST */
    protected function filterPostFields(array $payload): array
    {
        $out = $payload;
        unset($out['_sign_string']);

        return $out;
    }

    /** Отримати ID замовлення з різних можливих властивостей */
    protected function getOrderId($order): string
    {
        if (isset($order->order_id)) {
            return (string)$order->order_id;
        }
        if (isset($order->id)) {
            return (string)$order->id;
        }
        if (method_exists($order, 'get') && $order->get('order_id')) {
            return (string)$order->get('order_id');
        }

        return (string)($order->orderpayment_id ?? uniqid('order_', true));
    }

    /** Загальна сума замовлення (grand total) */
    protected function getOrderTotal($order): float
    {
        foreach (['grand_total', 'order_total', 'total', 'amount'] as $prop) {
            if (isset($order->$prop)) {
                return (float)$order->$prop;
            }
        }
        if (method_exists($order, 'get') && $order->get('order_total')) {
            return (float)$order->get('order_total');
        }

        return 0.0;
    }

    /** Код валюти замовлення (ALPHA, напр. UAH) */
    protected function getOrderCurrencyAlpha($order): string
    {
        foreach (['currency_code', 'order_currency', 'currency'] as $prop) {
            if (!empty($order->$prop)) {
                return (string)$order->$prop;
            }
        }
        if (method_exists($order, 'get') && $order->get('order_currency')) {
            return (string)$order->get('order_currency');
        }

        return 'UAH';
    }

    /** Мапа підтримуваних валют */
    protected function availableCurrencies(): array
    {
        return [
            'USD' => '840',
            'EUR' => '978',
            'UAH' => '980',
            'BAM' => '977',
            'HUF' => '348',
            'BGN' => '975',
            'RSD' => '941',
            'ALL' => '008',
        ];
    }

    protected function getSessionToken(): string
    {
        return (string)Factory::getSession()->getId();
    }

    protected function getSiteName(): string
    {
        return (string)Factory::getApplication()->get('sitename', 'Joomla');
    }

    protected function handleCallback(): void
    {
        $app = Factory::getApplication();
        $post = $app->input->post->getArray([]);

        $this->log('CALLBACK POST: ' . json_encode($post));

        if (empty($post)) {
            $this->replyReverse('Empty POST');
        }

        $orderId = $post['OrderID'] ?? null;
        if (!$orderId) {
            $this->replyReverse('OrderID missing');
        }

        $signString = $this->buildCallbackSignString($post);
        $signature = $post['Signature'] ?? '';

        $isTest = (int)$this->params->get('testmode', 1) === 1;
        $verified = $isTest ? true : $this->verifySignature($signString, $signature);

        if (!$verified) {
            $this->log('SIGNATURE FAIL for order ' . $orderId);

            $this->replyReverse('Signature verification failed');
        }

        $tran = (string)($post['TranCode'] ?? '');
        $delay = (string)($post['Delay'] ?? '0') === '1';

        if ($tran === '000') {

            $this->saveTxnMeta($orderId, $post);
            $this->saveUserTokenFromCallback($orderId, $post);
            // on-hold для pre-auth, інакше success
            if ($delay) {
                $this->markOrderAuthorized($orderId, $post);
            } else {
                $this->markOrderPaid($orderId, $post);
            }

            $this->replyApprove($post, $orderId);
        } else {
            $this->markOrderFailed($orderId, $post);
            $this->replyReverse('Transaction declined (TranCode=' . $tran . ')');
        }
    }

    protected function buildCallbackSignString(array $p): string
    {
        $MerchantID = $p['MerchantID'] ?? '';
        $TerminalID = $p['TerminalID'] ?? '';
        $PurchaseTime = $p['PurchaseTime'] ?? '';
        $OrderID = $p['OrderID'] ?? '';
        $Delay = $p['Delay'] ?? '';
        $XID = $p['XID'] ?? '';
        $Currency = $p['Currency'] ?? '';
        $AltCurrency = $p['AltCurrency'] ?? '';
        $TotalAmount = $p['TotalAmount'] ?? '';
        $AltTotal = $p['AltTotalAmount'] ?? '';
        $SD = $p['SD'] ?? '';
        $TranCode = $p['TranCode'] ?? '';
        $ApprovalCode = $p['ApprovalCode'] ?? '';
        $upcToken = $p['UPCToken'] ?? null;
        $upcTokenExp = $p['UPCTokenExp'] ?? null;

        $data = sprintf(
            '%s;%s;%s;%s,%s;%s;%s,%s;%s,%s;%s;%s;%s;%s%s',
            $MerchantID,
            $TerminalID,
            $PurchaseTime,
            $OrderID,
            $Delay,
            $XID,
            $Currency,
            $AltCurrency,
            $TotalAmount,
            $AltTotal,
            $SD,
            $TranCode,
            $ApprovalCode,
            $upcToken ?? '',
            $upcTokenExp ? ',' . $upcTokenExp . ';' : ''
        );

        $this->log('SIGN STRING: ' . $data);

        return $data;
    }

    protected function verifySignature(string $data, string $b64sig): bool
    {
        $crt = (int)$this->params->get('testmode', 1) === 1
            ? (string)$this->params->get('test_crt', '')
            : (string)$this->params->get('work_crt', '');

        if (empty($crt) || empty($b64sig)) {
            return false;
        }

        $pem = $crt;

        $pub = openssl_pkey_get_public($pem);
        if ($pub === false) {
            return false;
        }

        $sig = base64_decode($b64sig, true);
        if ($sig === false) {
            return false;
        }

        $ok = openssl_verify($data, $sig, $pub, OPENSSL_ALGO_SHA512) === 1;

        return $ok;
    }

    #[NoReturn]
    protected function replyApprove(array $p, string $orderId): void
    {
        $forward = Uri::root() .
                   'index.php?option=com_j2store&view=checkout' .
                   '&task=confirmPayment&orderpayment_type=' . $this->_element .
                   '&paction=display';

        echo "MerchantID = " . ($p['MerchantID'] ?? '') . "\n";
        echo "TerminalID = " . ($p['TerminalID'] ?? '') . "\n";
        echo "OrderID = " . $orderId . "\n";
        echo "Currency = " . ($p['Currency'] ?? '') . "\n";
        echo "TotalAmount = " . ($p['TotalAmount'] ?? '') . "\n";
        echo "XID = " . ($p['XID'] ?? '') . "\n";
        echo "PurchaseTime = " . ($p['PurchaseTime'] ?? '') . "\n";
        echo "ApprovalCode= " . ($p['ApprovalCode'] ?? '') . "\n";
        echo "SD= " . ($p['SD'] ?? '') . "\n";
        echo "TranCode= " . ($p['TranCode'] ?? '') . "\n";
        echo "Response.action= approve\n";
        echo "Response.reason= ok\n";
        echo "Response.forwardUrl= " . $forward . "\n";
        exit;
    }

    #[NoReturn]
    protected function replyReverse(string $reason): void
    {
        $failureUrl = $this->getFailureUrl();

        echo "Response.action= reverse\n";
        echo "Response.reason= " . $reason . "\n";
        echo "Response.forwardUrl= " . $failureUrl . "\n";
        exit;
    }

    private function getFailureUrl(): string
    {
        $url = trim((string) $this->params->get('failure_url', ''));

        if ($url !== '') {
            return $url;
        }

        return rtrim(Uri::root(), '/');
    }

    protected function markOrderPaid($orderIdFromGateway, array $p): void
    {
        $orderId = $this->resolveInternalOrderId($orderIdFromGateway);
        if (!$orderId) {
            $this->log("PAID: cannot resolve internal order id for '{$orderIdFromGateway}'");

            return;
        }
        $stateId = $this->mapStatusAliasToId($this->params->get('custom_success_status', 'processing'));
        $this->setOrderStateId($orderId, $stateId);
        $this->log("ORDER {$orderId} ← PAID stateId={$stateId}");
    }

    protected function markOrderAuthorized($orderIdFromGateway, array $p): void
    {
        $orderId = $this->resolveInternalOrderId($orderIdFromGateway);
        if (!$orderId) {
            $this->log("AUTHORIZED: cannot resolve internal order id for '{$orderIdFromGateway}'");

            return;
        }

        $this->setOrderStateId($orderId, 5);
        $this->log("ORDER {$orderId} ← AUTHORIZED (Unpaid=5)");
    }

    protected function markOrderFailed($orderIdFromGateway, array $p): void
    {
        $orderId = $this->resolveInternalOrderId($orderIdFromGateway);
        if (!$orderId) {
            $this->log("FAILED: cannot resolve internal order id for '{$orderIdFromGateway}'");

            return;
        }
        // Failed — 3
        $this->setOrderStateId($orderId, 3);
        $this->log("ORDER {$orderId} ← FAILED (3)");
    }

    /** Пряме оновлення стовпця order_state_id у #__j2store_orders */
    protected function setOrderStateId(int $orderId, int $stateId): void
    {
        try {
            $db = \Joomla\CMS\Factory::getDbo();
            $obj = (object)[
                'order_id' => $orderId,
                'order_state_id' => $stateId,
            ];
            $db->updateObject('#__j2store_orders', $obj, 'order_id');
        } catch (\Throwable $e) {
            $this->log('setOrderStateId error: ' . $e->getMessage());
        }
    }

    /** Мапа «аліаса» з налаштувань → ID зі сторінки замовлення */
    protected function mapStatusAliasToId(string $alias): int
    {
        return match (strtolower(trim($alias))) {
            'confirmed', 'complete', 'completed' => 1,
            'processing', 'processed' => 2,
            'failed' => 3,
            'pending', 'on-hold', 'authorized' => 4,
            'unpaid' => 5,
            'cancelled', 'canceled' => 6,
            default => 2,
        };
    }

    /** Спроба знайти реальний #__j2store_orders.order_id за зовнішнім OrderID з UPC */
    protected function resolveInternalOrderId($external): ?int
    {
        $db = \Joomla\CMS\Factory::getDbo();
        $external = trim((string)$external);

        $candidates = [
            ['table' => '#__j2store_orders', 'col' => 'order_id'],
            ['table' => '#__j2store_orders', 'col' => 'orderpayment_id'],
            ['table' => '#__j2store_orders', 'col' => 'order_number'],
            ['table' => '#__j2store_orders', 'col' => 'orderinvoice'],
        ];

        foreach ($candidates as $c) {
            try {
                $query = $db->getQuery(true)
                            ->select($db->qn('order_id'))
                            ->from($db->qn($c['table']))
                            ->where($db->qn($c['col']) . ' = ' . $db->q($external))
                            ->setLimit(1);
                $db->setQuery($query);
                $id = (int)$db->loadResult();
                if ($id > 0) {
                    if ($c['col'] !== 'order_id') {
                        $this->log("Resolved internal order_id={$id} by {$c['col']}='{$external}'");
                    }

                    return $id;
                }
            } catch (\Throwable $e) {
                $this->log("resolveInternalOrderId error [{$c['col']}] : " . $e->getMessage());
            }
        }

        if (ctype_digit($external)) {
            return (int)$external;
        }

        return null;
    }

    protected function saveTxnMeta(string $externalOrderId, array $p): void
    {
        try {
            $db = \Joomla\CMS\Factory::getDbo();
            $db->setQuery("
            CREATE TABLE IF NOT EXISTS `#__ecc_tx` (
              `id`              INT AUTO_INCREMENT PRIMARY KEY,
              `order_id`        varchar(255) NOT NULL,
              `gateway_order_id`VARCHAR(64),
              `purchase_time`   VARCHAR(14),
              `approval_code`   VARCHAR(32),
              `rrn`             VARCHAR(32),
              `signature`       TEXT,
              `xid`             VARCHAR(64),
              `sd`              VARCHAR(64),
              `proxy_pan`       VARCHAR(32),
              `currency`        VARCHAR(8),
              `alt_currency`    VARCHAR(8),
              `total_amount`    INT,
              `alt_total_amount`INT,
              `delay`           TINYINT(1),
              `created_at`      DATETIME DEFAULT CURRENT_TIMESTAMP,
              KEY(`order_id`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        ")->execute();

            $internalId = $this->resolveInternalOrderId($externalOrderId);
            if (!$internalId) {
                $this->log("saveTxnMeta: cannot resolve internal id for {$externalOrderId}");

                return;
            }

            $row = (object)[
                'order_id' => (int)$internalId,
                'gateway_order_id' => (string)($p['OrderID'] ?? ''),
                'purchase_time' => (string)($p['PurchaseTime'] ?? ''),
                'approval_code' => (string)($p['ApprovalCode'] ?? ''),
                'rrn' => (string)($p['Rrn'] ?? ''),
                'signature' => (string)($p['Signature'] ?? ''),
                'xid' => (string)($p['XID'] ?? ''),
                'sd' => (string)($p['SD'] ?? ''),
                'proxy_pan' => (string)($p['ProxyPan'] ?? ''),
                'currency' => (string)($p['Currency'] ?? ''),
                'alt_currency' => (string)($p['AltCurrency'] ?? ''),
                'total_amount' => (int)($p['TotalAmount'] ?? 0),
                'alt_total_amount' => (int)($p['AltTotalAmount'] ?? 0),
                'delay' => (string)($p['Delay'] ?? '0') === '1' ? 1 : 0,
            ];
            $db->insertObject('#__ecc_tx', $row);
            $this->log("TX meta saved for order {$internalId}");
        } catch (\Throwable $e) {
            $this->log('saveTxnMeta error: ' . $e->getMessage());
        }
    }

    /** З callback: зберегти токен на користувача (якщо є користувач і токен валідний) */
    protected function saveUserTokenFromCallback(string $externalOrderId, array $p): void
    {
        $token = trim((string)($p['UPCToken'] ?? ''));
        $exp = trim((string)($p['UPCTokenExp'] ?? ''));
        if ($token === '' || $exp === '') {
            return;
        }
        if (!$this->isUpcTokenValid($exp)) {
            $this->log("UPCToken expired/invalid: $exp");

            return;
        }

        $userId = $this->resolveUserIdByOrderId($externalOrderId);
        if (!$userId) {
            $this->log("No user for order $externalOrderId (guest order?)");

            return;
        }

        $this->upsertUserToken((int)$userId, $token, $exp);
        $this->log("Saved UPCToken for user $userId (exp=$exp)");
    }

    /** Перевірка формату MMyyyy і що токен не прострочений */
    protected function isUpcTokenValid(string $exp): bool
    {
        if (!preg_match('/^(0[1-9]|1[0-2])\d{4}$/', $exp)) {
            return false;
        }
        $mm = (int)substr($exp, 0, 2);
        $yyyy = (int)substr($exp, 2, 4);
        $nowY = (int)date('Y');
        $nowM = (int)date('m');

        return ($yyyy > $nowY) || ($yyyy === $nowY && $mm >= $nowM);
    }

    /** Створює (якщо треба) таблицю та зберігає токен на користувача */
    protected function upsertUserToken(int $userId, string $token, string $exp): void
    {
        try {
            $db = Factory::getDbo();

            $create = <<<SQL
            CREATE TABLE IF NOT EXISTS `#__ecc_user_tokens` (
              `user_id`       INT NOT NULL PRIMARY KEY,
              `upc_token`     VARCHAR(64) NOT NULL,
              `upc_token_exp` VARCHAR(8)  NOT NULL,
              `updated_at`    DATETIME DEFAULT CURRENT_TIMESTAMP
                               ON UPDATE CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
            SQL;

            $db->setQuery($create)->execute();

            $token = substr($token, 0, 64);
            $exp   = substr($exp,   0, 8);

            $sql = sprintf(
                "INSERT INTO %s (%s,%s,%s) VALUES (%d,%s,%s)
             ON DUPLICATE KEY UPDATE %s=VALUES(%s), %s=VALUES(%s)",
                $db->qn('#__ecc_user_tokens'),
                $db->qn('user_id'), $db->qn('upc_token'), $db->qn('upc_token_exp'),
                (int) $userId, $db->q($token), $db->q($exp),
                $db->qn('upc_token'), $db->qn('upc_token'),
                $db->qn('upc_token_exp'), $db->qn('upc_token_exp')
            );

            $db->setQuery($sql)->execute();
        } catch (\Throwable $e) {
            $this->log('upsertUserToken error: ' . $e->getMessage());
        }
    }

    /** Отримати user_id із замовлення (працюємо з різними схемами) */
    protected function resolveUserIdByOrderId(int $OrderId): ?int
    {
        /** @var DatabaseDriver $db */
        $db = Factory::getContainer()->get('DatabaseDriver');

        $query = $db->getQuery(true)
                    ->select($db->quoteName('user_id'))
                    ->from($db->quoteName('#__j2store_orders'))
                    ->where($db->quoteName('order_id') . ' = ' . $db->quote($OrderId))
                    ->setLimit(1);

        $db->setQuery($query);
        $uid = (int)$db->loadResult();
        if ($uid > 0) {
            return $uid;
        }

        $query = $db->getQuery(true)
                    ->select($db->quoteName('user_email'))
                    ->from($db->quoteName('#__j2store_orders'))
                    ->where($db->quoteName('order_id') . ' = ' . $db->quote($OrderId))
                    ->setLimit(1);

        $db->setQuery($query);
        $email = (string)$db->loadResult();

        if ($email !== '') {
            $query = $db->getQuery(true)
                        ->select($db->quoteName('id'))
                        ->from($db->quoteName('#__users'))
                        ->where($db->quoteName('email') . ' = ' . $db->quote($email))
                        ->setLimit(1);

            $db->setQuery($query);
            $uid = (int)$db->loadResult();
            if ($uid > 0) {
                return $uid;
            }
        }

        return null;
    }

    /** Повернути валідний токен користувача за поточним замовленням */
    protected function getStoredUserTokenForOrder($order): ?string
    {
        $internalId = $this->resolveInternalOrderId($this->getOrderId($order));
        if (!$internalId) {
            return null;
        }
        $userId = $this->resolveUserIdByOrderId((int)$internalId);
        if (!$userId) {
            return null;
        }

        try {
            $db = \Joomla\CMS\Factory::getDbo();
            $q = $db->getQuery(true)
                    ->select([$db->qn('upc_token'), $db->qn('upc_token_exp')])
                    ->from($db->qn('#__ecc_user_tokens'))
                    ->where($db->qn('user_id') . '=' . (int)$userId)
                    ->setLimit(1);
            $db->setQuery($q);
            $row = $db->loadObject();
            if ($row && $this->isUpcTokenValid((string)$row->upc_token_exp)) {
                return (string)$row->upc_token;
            }
        } catch (\Throwable $e) {
            $this->log('getStoredUserTokenForOrder error: ' . $e->getMessage());
        }

        return null;
    }

    protected function log(string $msg): void
    {
        $isTest = (int)$this->params->get('testmode', 1) === 1;
        if ($isTest) {
            try {
                $path = JPATH_ADMINISTRATOR . '/logs/ecc.log';
                @file_put_contents($path, '[' . date('c') . '] ' . $msg . PHP_EOL, FILE_APPEND);
            } catch (\Throwable $e) {
            }
        }
    }

    protected function requireAdminAndToken(): void
    {
        $app = \Joomla\CMS\Factory::getApplication();
        $user = \Joomla\CMS\Factory::getUser();

        if (!Session::checkToken('request')) {
            echo 'Invalid token';
            exit;
        }

        if (!$user->authorise('core.manage', 'com_j2store')) {
            echo 'Forbidden';
            exit;
        }
    }

    protected function getTxnRow(int $internalOrderId)
    {
        $db = \Joomla\CMS\Factory::getDbo();
        $q = $db->getQuery(true)
                ->select('*')->from($db->qn('#__ecc_tx'))
                ->where($db->qn('order_id') . '=' . (int)$internalOrderId)
                ->order($db->qn('id') . ' DESC')->setLimit(1);
        $db->setQuery($q);

        return $db->loadObject();
    }

    protected function handleCapture(): void
    {
        $this->requireAdminAndToken();
        $app = \Joomla\CMS\Factory::getApplication();
        $oidExt = $app->input->getString('oid');
        $amountUi = $app->input->getString('amt');
        $internal = $this->resolveInternalOrderId($oidExt);
        if (!$internal) {
            echo 'Order not found';
            exit;
        }

        $tx = $this->getTxnRow($internal);
        if (!$tx) {
            echo 'No txn meta found';
            exit;
        }

        $amountCents = (int)round((float)$amountUi * 100);

        $postData = [
            'MerchantID' => (string)$this->params->get('merchant_id', ''),
            'TerminalID' => (string)$this->params->get('terminal_id', ''),
            'OrderID' => (string)$tx->gateway_order_id,
            'Currency' => (string)$tx->currency,
            'TotalAmount' => (int)$tx->total_amount,
            'PurchaseTime' => (string)$tx->purchase_time,
            'ApprovalCode' => (string)$tx->approval_code,
            'RRN' => (string)$tx->rrn,
            'PostauthorizationAmount' => $amountCents,
            'Signature' => (string)$tx->signature,
        ];

        $url = rtrim((string)$this->params->get('url', ''), '/') . '/go/capture';
        $http = HttpFactory::getHttp();
        $resp = $http->post($url, http_build_query($postData), ['Content-Type' => 'application/x-www-form-urlencoded']);
        $body = (string)($resp->body ?? '');

        $parsed = $this->parseKeyValueResponse($body);
        $this->log('CAPTURE RESP: ' . json_encode($parsed));

        if (($parsed['TranCode'] ?? '') === '000') {
            $stateId = $this->mapStatusAliasToId($this->params->get('custom_success_status', 'processing'));
            $this->setOrderStateId((int)$internal, $stateId);
            echo 'OK';
            exit;
        } else {
            echo 'Capture failed: ' . htmlspecialchars($body);
            exit;
        }
    }

    protected function parseKeyValueResponse(string $html): array
    {
        if (preg_match('/<p>(.*?)<\/p>/s', $html, $m)) {
            $s = trim($m[1]);
        } else {
            $s = trim(strip_tags($html));
        }
        $out = [];
        foreach (preg_split('/\r?\n/', $s) as $line) {
            $line = trim($line);
            if ($line === '' || strpos($line, '=') === false) {
                continue;
            }
            [$k, $v] = array_map('trim', explode('=', $line, 2));
            $out[$k] = $v;
        }

        return $out;
    }

    /**
     * Перед збереженням: якщо секретне поле порожнє — не перезаписуємо старе;
     * якщо є нове значення — оновлюємо.
     */
    public function onExtensionBeforeSave($context, $table, $isNew)
    {
        if ($context !== 'com_plugins.plugin' || (string)($table->element ?? '') !== 'payment_ecommerceconnect' || (string)($table->folder ?? '') !== 'j2store') {
            return true;
        }

        $db = Factory::getContainer()->get(DatabaseDriver::class);

        $query = $db->getQuery(true)
                    ->select($db->quoteName('params'))
                    ->from($db->quoteName('#__extensions'))
                    ->where($db->quoteName('extension_id') . ' = ' . (int) $table->extension_id)
                    ->setLimit(1);

        $db->setQuery($query);
        $oldParamsJson = (string) $db->loadResult();
        $old = new Registry($oldParamsJson ?: '{}');

        $new = new Registry($table->params ?? '{}');

        foreach ($this->secretFields as $field) {
            $incoming = trim((string) $new->get($field, ''));
            if ($incoming === '') {
                $new->set($field, $old->get($field, ''));
            } else {
                $new->set($field, $incoming);
            }
        }

        $table->params = $new->toString();

        return true;
    }

    /**
     * Після збереження: повідомляємо, які секрети було оновлено.
     */
    public function onExtensionAfterSave($context, $table, $isNew)
    {
        if ($context !== 'com_plugins.plugin' || (string)($table->element ?? '') !== 'payment_ecommerceconnect' || (string)($table->folder ?? '') !== 'j2store') {
            return true;
        }

        $app = Factory::getApplication();
        $db  = Factory::getContainer()->get(DatabaseDriver::class);

        $query = $db->getQuery(true)
                    ->select($db->quoteName('params'))
                    ->from($db->quoteName('#__extensions'))
                    ->where($db->quoteName('extension_id') . ' = ' . (int) $table->extension_id)
                    ->setLimit(1);
        $db->setQuery($query);
        $currentParamsJson = (string) $db->loadResult();

        $current = new Registry($currentParamsJson ?: '{}');

        $input = $app->getInput();
        $posted = (array) ($input->post->get('jform', [], 'array')['params'] ?? []);

        $updated = [];
        $map = [
            'private_key'      => 'PLG_ECC_NOTICE_UPDATED_PRIVATE_KEY',
            'private_key_test' => 'PLG_ECC_NOTICE_UPDATED_PRIVATE_KEY_TEST',
            'work_crt'         => 'PLG_ECC_NOTICE_UPDATED_CERT_WORK',
            'test_crt'         => 'PLG_ECC_NOTICE_UPDATED_CERT_TEST',
        ];

        foreach ($this->secretFields as $field) {
            $raw = trim((string) ($posted[$field] ?? ''));
            if ($raw !== '') {
                $updated[] = Text::_($map[$field]);
            }
        }

        if ($updated) {
            $app->enqueueMessage(implode('<br>', $updated), 'message');
        }

        return true;
    }
}