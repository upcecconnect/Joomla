<?php defined('_JEXEC') or die; ?>
<div class="j2store-payment-method">
    <?php if (!empty($vars->logo)) : ?>
        <img src="<?php echo htmlspecialchars($vars->logo); ?>" alt="eCommerceConnect" style="max-height:28px;margin-right:8px;">
    <?php endif; ?>
    <strong><?php echo htmlspecialchars($vars->title ?? 'eCommerceConnect'); ?></strong><br>
    <small><?php echo htmlspecialchars($vars->description ?? ''); ?></small>
</div>