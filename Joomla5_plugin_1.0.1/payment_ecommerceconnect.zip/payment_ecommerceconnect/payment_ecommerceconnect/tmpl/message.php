<?php defined('_JEXEC') or die; ?>
<div class="alert alert-info"><?php echo $vars->message ?? ''; ?></div>
