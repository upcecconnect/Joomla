<?php defined('_JEXEC') or die; ?>
<form id="ecc-pay-form" method="post" action="<?php echo htmlspecialchars($vars->action_url); ?>">
  <?php foreach (($vars->fields ?? []) as $name => $value): ?>
    <input type="hidden" name="<?php echo htmlspecialchars($name); ?>" value="<?php echo htmlspecialchars((string)$value); ?>">
  <?php endforeach; ?>
  <button type="submit" class="btn btn-primary">
    <?php echo JText::_('PLG_ECC_BTN_PAY'); ?>
  </button>
</form>

<?php if (!empty($vars->skip_form)): ?>
  <script>
    document.addEventListener('DOMContentLoaded', function(){
      var f = document.getElementById('ecc-pay-form');
      if (f) f.submit();
    });
  </script>
<?php endif; ?>
